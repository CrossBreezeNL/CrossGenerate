CREATE VIEW [archive].[current_Order]
AS 
	SELECT 
		Id,
		OrderDate,
		OrderNumber,
		CustomerId,
		TotalAmount
	FROM archive.[Order]
	WHERE IsValid = 1
