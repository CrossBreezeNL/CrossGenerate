CREATE TABLE [archive].[Order]
(
    [BatchId] INT NOT NULL, 
    [Id] int NOT NULL , 
    [OrderDate] datetime NULL, 
    [OrderNumber] varchar(50) NULL, 
    [CustomerId] int NULL, 
    [TotalAmount] decimal(12, 2) NULL, 
    [Update_BatchId] INT NULL,
    [IsValid]   Bit Default 1 NOT NULL
    PRIMARY KEY ([BatchId]
    ,[Id]
    )
)
