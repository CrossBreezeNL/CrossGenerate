CREATE VIEW [archive].[current_Customer]
AS 
	SELECT 
		Id,
		FirstName,
		LastName,
		City,
		Country,
		Phone
	FROM archive.[Customer]
	WHERE IsValid = 1
