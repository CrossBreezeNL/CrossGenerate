CREATE PROCEDURE [archive].[update_Order]
	@batchId INT
AS
BEGIN
	-- update records in Order for which a new, modified record is found in the staging table
	UPDATE a
		SET	IsValid = 0,
			Update_BatchId = @batchId
	FROM archive.[Order] a
	INNER JOIN staging.[Order] s
	  ON
		a.Id = s.Id
	WHERE a.IsValid = 1
	AND (
	((a.OrderDate != s.OrderDate) OR (a.OrderDate IS NULL AND s.OrderDate IS NOT NULL) OR (a.OrderDate IS NOT NULL and s.OrderDate IS NULL))
	 OR ((a.OrderNumber != s.OrderNumber) OR (a.OrderNumber IS NULL AND s.OrderNumber IS NOT NULL) OR (a.OrderNumber IS NOT NULL and s.OrderNumber IS NULL))
	 OR ((a.CustomerId != s.CustomerId) OR (a.CustomerId IS NULL AND s.CustomerId IS NOT NULL) OR (a.CustomerId IS NOT NULL and s.CustomerId IS NULL))
	 OR ((a.TotalAmount != s.TotalAmount) OR (a.TotalAmount IS NULL AND s.TotalAmount IS NOT NULL) OR (a.TotalAmount IS NOT NULL and s.TotalAmount IS NULL))
	);


	--Insert all records from the staging table for which a valid record is not found in the archive
	INSERT INTO archive.[Order]
	(
		Id,
		OrderDate,
		OrderNumber,
		CustomerId,
		TotalAmount,
		BatchId,
		IsValid,
		Update_BatchId
	)
	SELECT 
		s.Id,
		s.OrderDate,
		s.OrderNumber,
		s.CustomerId,
		s.TotalAmount,
		@batchId,
		1,
		NULL
	FROM staging.[Order] s
	LEFT JOIN archive.[Order] a
	   ON a.IsValid = 1
	  AND a.Id = s.Id
	WHERE a.BatchId IS NULL;
END