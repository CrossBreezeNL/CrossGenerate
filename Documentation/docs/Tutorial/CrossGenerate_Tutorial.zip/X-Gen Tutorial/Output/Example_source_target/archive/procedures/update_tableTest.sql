CREATE PROCEDURE [archive].[update_tableTest]
	@batchId INT
AS
BEGIN
	-- update records in tableTest for which a new, modified record is found in the staging table
	UPDATE a
		SET	IsValid = 0,
			Update_BatchId = @batchId
	FROM archive.[tableTest] a
	INNER JOIN staging.[tableTest] s
	  ON
		a.TestId = s.TestId AND
		a.keyAttribute_name = s.keyAttribute_name
	WHERE a.IsValid = 1
	AND (
	((a.nonKeyAttribute_name != s.nonKeyAttribute_name) OR (a.nonKeyAttribute_name IS NULL AND s.nonKeyAttribute_name IS NOT NULL) OR (a.nonKeyAttribute_name IS NOT NULL and s.nonKeyAttribute_name IS NULL))
	);


	--Insert all records from the staging table for which a valid record is not found in the archive
	INSERT INTO archive.[tableTest]
	(
		TestId,
		keyAttribute_name,
		nonKeyAttribute_name,
		BatchId,
		IsValid,
		Update_BatchId
	)
	SELECT 
		s.TestId,
		s.keyAttribute_name,
		s.nonKeyAttribute_name,
		@batchId,
		1,
		NULL
	FROM staging.[tableTest] s
	LEFT JOIN archive.[tableTest] a
	   ON a.IsValid = 1
	  AND a.TestId = s.TestId
	  AND a.keyAttribute_name = s.keyAttribute_name
	WHERE a.BatchId IS NULL;
END