CREATE TABLE [archive].[tableTest]
(
    [BatchId] INT NOT NULL, 
    [TestId] int NOT NULL , 
    [keyAttribute_name] varchar(10) NOT NULL , 
    [nonKeyAttribute_name] varchar(10) NULL, 
    [Update_BatchId] INT NULL,
    [IsValid]   Bit Default 1 NOT NULL
    PRIMARY KEY ([BatchId]
    ,[TestId]
    ,[keyAttribute_name]
    )
)
