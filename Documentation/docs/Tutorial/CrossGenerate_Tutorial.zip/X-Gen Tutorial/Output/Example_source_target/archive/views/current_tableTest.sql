CREATE VIEW [archive].[current_tableTest]
AS 
	SELECT 
		TestId,
		keyAttribute_name,
		nonKeyAttribute_name
	FROM archive.[tableTest]
	WHERE IsValid = 1
