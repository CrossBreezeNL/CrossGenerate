CREATE PROCEDURE [archive].[update_Customer]
	@batchId INT
AS
BEGIN
	-- update records in Customer for which a new, modified record is found in the staging table
	UPDATE a
		SET	IsValid = 0,
			Update_BatchId = @batchId
	FROM archive.[Customer] a
	INNER JOIN staging.[Customer] s
	  ON
		a.Id = s.Id
	WHERE a.IsValid = 1
	AND (
	((a.FirstName != s.FirstName) OR (a.FirstName IS NULL AND s.FirstName IS NOT NULL) OR (a.FirstName IS NOT NULL and s.FirstName IS NULL))
	 OR ((a.LastName != s.LastName) OR (a.LastName IS NULL AND s.LastName IS NOT NULL) OR (a.LastName IS NOT NULL and s.LastName IS NULL))
	 OR ((a.City != s.City) OR (a.City IS NULL AND s.City IS NOT NULL) OR (a.City IS NOT NULL and s.City IS NULL))
	 OR ((a.Country != s.Country) OR (a.Country IS NULL AND s.Country IS NOT NULL) OR (a.Country IS NOT NULL and s.Country IS NULL))
	 OR ((a.Phone != s.Phone) OR (a.Phone IS NULL AND s.Phone IS NOT NULL) OR (a.Phone IS NOT NULL and s.Phone IS NULL))
	);


	--Insert all records from the staging table for which a valid record is not found in the archive
	INSERT INTO archive.[Customer]
	(
		Id,
		FirstName,
		LastName,
		City,
		Country,
		Phone,
		BatchId,
		IsValid,
		Update_BatchId
	)
	SELECT 
		s.Id,
		s.FirstName,
		s.LastName,
		s.City,
		s.Country,
		s.Phone,
		@batchId,
		1,
		NULL
	FROM staging.[Customer] s
	LEFT JOIN archive.[Customer] a
	   ON a.IsValid = 1
	  AND a.Id = s.Id
	WHERE a.BatchId IS NULL;
END