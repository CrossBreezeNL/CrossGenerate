CREATE TABLE [staging].[tableTest]
(
    [BatchId] INT NOT NULL, 
    [TestId] int NOT NULL , 
    [keyAttribute_name] varchar(10) NOT NULL , 
    [nonKeyAttribute_name] varchar(10) NULL, 
    PRIMARY KEY ([BatchId]
    ,[TestId]
    ,[keyAttribute_name]
    )
)
