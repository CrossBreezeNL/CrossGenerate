CREATE TABLE [staging].[Order]
(
    [BatchId] INT NOT NULL, 
    [Id] int NOT NULL , 
    [OrderDate] datetime NULL, 
    [OrderNumber] varchar(50) NULL, 
    [CustomerId] int NULL, 
    [TotalAmount] decimal(12, 2) NULL, 
    PRIMARY KEY ([BatchId]
    ,[Id]
    )
)
