CREATE SCHEMA [archive]
