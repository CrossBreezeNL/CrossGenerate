﻿CREATE VIEW [archive].[current_table_name]
AS 
	SELECT 
		--@XGenTextSection(name='keyAttribute')
		keyAttribute_name,
		--@XGenTextSection(name='nonKeyAttribute' suffix=',')
		nonKeyAttribute_name
	FROM archive.[table_name]
	WHERE IsValid = 1
