﻿CREATE PROCEDURE [archive].[update_table_name]
	@batchId INT
AS
BEGIN
	-- update records in table_name for which a new, modified record is found in the staging table
	UPDATE a
		SET	IsValid = 0,
			Update_BatchId = @batchId
	FROM archive.[table_name] a
	INNER JOIN staging.[table_name] s
	  ON
		--@XGenTextSection(name='keyAttribute' suffix=' AND')
		a.keyAttribute_name = s.keyAttribute_name
	WHERE a.IsValid = 1
	AND (
	--@XGenTextSection(name='nonKeyAttribute' prefix = ' OR ')
	((a.nonKeyAttribute_name != s.nonKeyAttribute_name) OR (a.nonKeyAttribute_name IS NULL AND s.nonKeyAttribute_name IS NOT NULL) OR (a.nonKeyAttribute_name IS NOT NULL and s.nonKeyAttribute_name IS NULL))
	);


	--Insert all records from the staging table for which a valid record is not found in the archive
	INSERT INTO archive.[table_name]
	(
		--@XGenTextSection(name='keyAttribute')
		keyAttribute_name,
		--@XGenTextSection(name='nonKeyAttribute')
		nonKeyAttribute_name,
		BatchId,
		IsValid,
		Update_BatchId
	)
	SELECT 
		--@XGenTextSection(name='keyAttribute')
		s.keyAttribute_name,
		--@XGenTextSection(name='nonKeyAttribute')
		s.nonKeyAttribute_name,
		@batchId,
		1,
		NULL
	FROM staging.[table_name] s
	LEFT JOIN archive.[table_name] a
	   ON a.IsValid = 1
		--@XGenTextSection(name='keyAttribute')
	  AND a.keyAttribute_name = s.keyAttribute_name
	WHERE a.BatchId IS NULL;
END