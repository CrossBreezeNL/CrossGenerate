﻿CREATE TABLE [staging].[table_name]
(
    [BatchId] INT NOT NULL, 
    -- @XGenTextSection(name='keyAttribute')
    [keyAttribute_name] VARCHAR(10) NOT NULL , 
    -- @XGenTextSection(name='nonKeyAttribute')	
    [nonKeyAttribute_name] VARCHAR(10) NULL, 
    PRIMARY KEY ([BatchId]
    -- @XGenTextSection(name='keyAttribute')
    ,[keyAttribute_name]
    )
)
