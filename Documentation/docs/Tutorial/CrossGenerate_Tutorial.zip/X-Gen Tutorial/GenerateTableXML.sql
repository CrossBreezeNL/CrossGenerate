SELECT (select 'Example_source' as "@name",
		(select T.[TABLE_NAME] as "@name",
				(select column_name as "@name",
				 Cast(	CASE IS_NULLABLE
						WHEN 'Yes' THEN 'false'
						WHEN 'No' THEN 'true'
						end  as Varchar(100)) as "@required",
				cast ( Case 
						WHEN column_name IN (select C1.COLUMN_NAME FROM  
												INFORMATION_SCHEMA.TABLE_CONSTRAINTS TC1  
												JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE C1  
												ON C1.CONSTRAINT_NAME=TC1.CONSTRAINT_NAME  
												WHERE  
												 TC1.CONSTRAINT_TYPE='PRIMARY KEY' and C1.TABLE_NAME= C.TABLE_NAME  )
												 THEN 'true'
												 else 'false'
												 end
												 as varchar(10)
				) as "@primary" ,
				(SELECT [Type] = CASE 
									WHEN stp.[name] IN ('varchar', 'char') THEN stp.[name] + '(' + IIF(sc.max_length = -1, 'max', CAST(sc.max_length AS VARCHAR(25))) + ')' 
									WHEN stp.[name] IN ('nvarchar','nchar') THEN stp.[name] + '(' + IIF(sc.max_length = -1, 'max', CAST(sc.max_length / 2 AS VARCHAR(25)))+ ')'      
									WHEN stp.[name] IN ('decimal', 'numeric') THEN stp.[name] + '(' + CAST(sc.[precision] AS VARCHAR(25)) + ', ' + CAST(sc.[scale] AS VARCHAR(25)) + ')'
									WHEN stp.[name] IN ('datetime2') THEN stp.[name] + '(' + CAST(sc.[scale] AS VARCHAR(25)) + ')'
									ELSE stp.[name]
								END
				FROM sys.tables st 
				JOIN sys.schemas ss ON st.schema_id = ss.schema_id
				JOIN sys.columns sc ON st.object_id = sc.object_id
				JOIN sys.types stp ON sc.user_type_id = stp.user_type_id
				Where sc.name= c.COLUMN_NAME  and st.name=t.TABLE_NAME
				) as "@fulldatatype"
				from INFORMATION_SCHEMA.COLUMNS C
				where C.TABLE_NAME= T.TABLE_NAME
				for XML path ('column'), TYPE) as "columns" , 
				(SELECT TC.CONSTRAINT_NAME as "@id",
					(select KCU.column_name as "@id", KCU.ORDINAL_POSITION as "@OrdinalPosition"
					from INFORMATION_SCHEMA.KEY_COLUMN_USAGE KCU
					where KCU.TABLE_NAME= T.TABLE_NAME
					and KCU.CONSTRAINT_NAME = TC.CONSTRAINT_NAME
					for XML path ('keyColumn'), TYPE ) as "keyColumns"
				FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS TC
				where TC.TABLE_NAME= T.TABLE_NAME and TC.CONSTRAINT_TYPE= 'PRIMARY KEY'
				for XML path ('primaryKey'), TYPE) as "keys"
		from INFORMATION_SCHEMA.TABLES T
		where TABLE_CATALOG='Example_source'
		for XML path('table'), TYPE) as "tables"
	for XML path('database'), Type ) 



