﻿-- @XGenComment(This is the schema template for all mappable objects in the DWH)
CREATE SCHEMA [MappableObject_owner];