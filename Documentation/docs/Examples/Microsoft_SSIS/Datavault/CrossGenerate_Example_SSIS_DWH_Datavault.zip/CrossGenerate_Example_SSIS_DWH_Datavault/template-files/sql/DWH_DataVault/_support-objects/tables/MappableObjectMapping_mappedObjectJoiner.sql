CREATE TABLE [MappableObjectMapping_mappedObjectJoiner] (
  [MappedParameter_expression] [NonKeyAttribute_fulldatatype],
  [MappedAttribute_expression] [NonKeyAttribute_fulldatatype]
);
GO
