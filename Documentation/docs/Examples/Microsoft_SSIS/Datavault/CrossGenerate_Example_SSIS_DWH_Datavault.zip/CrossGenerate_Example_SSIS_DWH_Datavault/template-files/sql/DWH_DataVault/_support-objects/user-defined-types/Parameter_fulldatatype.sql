﻿CREATE TYPE [dbo].[Parameter_fulldatatype]
	FROM varchar(10)