﻿CREATE TABLE [Entity_owner].[Entity_name] (
    [Attribute_name] [dbo].[Attribute_fulldatatype] NOT NULL
);

