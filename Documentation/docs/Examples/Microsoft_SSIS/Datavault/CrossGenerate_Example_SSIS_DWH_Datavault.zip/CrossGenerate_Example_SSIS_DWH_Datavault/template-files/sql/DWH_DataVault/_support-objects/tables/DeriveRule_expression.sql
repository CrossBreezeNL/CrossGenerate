CREATE TABLE [dbo].[DeriveRule$expression] (
  [Attribute_name] [NonKeyAttribute_fulldatatype]
);
GO
