﻿CREATE TYPE [dbo].[Attribute_fulldatatype]
	FROM varchar(10)