CREATE TABLE [Entity_owner].[Entity_name] (
  -- @XGenTextSection(name="Attribute") 
  [Attribute_name]          Attribute_fulldatatype    NULL,
  [StageDateTime]           datetime2(2) NOT NULL,
);
GO
