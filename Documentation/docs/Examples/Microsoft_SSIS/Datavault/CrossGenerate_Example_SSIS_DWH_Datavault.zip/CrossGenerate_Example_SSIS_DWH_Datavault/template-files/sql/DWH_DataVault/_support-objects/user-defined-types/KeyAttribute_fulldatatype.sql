﻿CREATE TYPE [dbo].[KeyAttribute_fulldatatype]
	FROM varchar(10)