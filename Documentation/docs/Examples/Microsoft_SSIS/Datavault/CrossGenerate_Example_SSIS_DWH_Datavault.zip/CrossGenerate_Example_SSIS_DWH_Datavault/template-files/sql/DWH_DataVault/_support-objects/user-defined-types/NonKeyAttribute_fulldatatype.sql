﻿CREATE TYPE [dbo].[NonKeyAttribute_fulldatatype]
	FROM varchar(10)