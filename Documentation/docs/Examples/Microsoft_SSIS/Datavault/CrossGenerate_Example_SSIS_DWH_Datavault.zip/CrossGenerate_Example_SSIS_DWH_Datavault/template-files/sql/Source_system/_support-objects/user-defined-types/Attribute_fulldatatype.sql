﻿CREATE TYPE [dbo].[Attribute_fulldatatype]
    FROM VARCHAR (10) NOT NULL;

