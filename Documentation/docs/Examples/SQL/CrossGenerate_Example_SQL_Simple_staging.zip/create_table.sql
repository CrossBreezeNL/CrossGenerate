-- @XGenSection(name="CreateTable" placeholderOnLastLine="GO")
CREATE TABLE [system_name].[entity_name] (
  -- @XGenSection(name="TableColumn")
  [attribute_name]           attribute_fulldatatype        NULL,
  [StageDateTime]            datetime2(2)              NOT NULL  
);
GO